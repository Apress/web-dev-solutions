<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html dir="ltr" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
	<title>Meeting Agenda for Friday, 30.07.2006</title>
  <link rel="stylesheet" type="text/css" href="meetingagenda.css" />
</head>
<body>
  <h1>Meeting Agenda</h1>
  <h2>What to do with web standards</h2>
  <p>On Friday, the following attendees will meet to discuss the importance of standardization 
     of web communication:</p>
  <ul>
    <li class="commercial">Steve Jobs</li>
    <li id="chairman">Tim Berners-Lee</li>
    <li>Linus Torvalds</li>
    <li class="commercial">Bill Gates</li> 
    <li>Tantek Çelik</li>
  </ul>
  <?php echo '<p id="footer">&copy; Awesomemeetings.com 2006, Last modified:' . date ('F d Y H:i:s.', getlastmod()) . '</p>'?>
</body>
</html>
