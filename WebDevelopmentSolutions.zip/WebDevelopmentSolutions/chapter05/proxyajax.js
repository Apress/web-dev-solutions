YAHOO.example.proxyajax={

  // the initialization function 
  init:function(){

    // get all links with the class "delcious"	
    var links = YAHOO.util.Dom.getElementsByClassName('delicious','a');

	// fire the "get" method when the user clicks them 
    YAHOO.util.Event.addListener(links,'click',YAHOO.example.proxyajax.get);
  },

  // the get method that retrieves the information
  get:function(e){

    // if the data has not been loaded yet ... 
    if(this.hasloaded===undefined){

      // get the href attribute, which is the URL we will load 
      var url = this.getAttribute('href');

      // store the original link in a variable
      var origin = this;
      // store the original link text in a variable
      var text = this.innerHTML;
      // display a loading message 
      this.innerHTML = 'Loading...';

      // In order to turn a normal del.icio.us URL into a feed, just add RSS
      var feedurl = url.replace(/\.us/,'.us/rss');

      // the function to call when the loading was successful
      function delicioussuccess(o) { 
        
		// reset the text of the link
        origin.innerHTML = text;

        // set a flag that the content was already loaded
        origin.hasloaded = true;

        // get the root element of the XML feed
        var root = o.responseXML.documentElement;

		// get all the "item" elements in the feed
        var items = root.getElementsByTagName('item');

        // loop over all items, retrieve the link data and add it to a string
        var output = '';
        for(var i=0, j=items.length; i<j; i++){
          var title = items[i].getElementsByTagName('title')[0].firstChild.nodeValue;
          var url = items[i].getElementsByTagName('link')[0].firstChild.nodeValue;
          output+='<li><a href="' + url + '">' + title + '</a></li>'      
        }

        // create a new list element and give it the CSS class linkslist 
        var list = document.createElement('ul');
        list.className = 'linkslist';

        // insert the list after the link parent (which is the paragraph it resides in)
        origin.parentNode.parentNode.insertBefore(list,origin.parentNode.nextSibling);

        // and add all the links as its content
        list.innerHTML = output;
      }

      // if there was any communication error, just redirect the browser
      function deliciousfailure(o){ 
        window.location = url;
      }

      // the handlers for the connection 
      var delicioushandlers={
        success: delicioussuccess,
        failure: deliciousfailure 
      }

	  // send the URL to the server side script as an asynchronous request
      var cObj = YAHOO.util.Connect.asyncRequest('GET', 'get.php?url='+feedurl, delicioushandlers);

	// if there is already a list of links, just toggle their display   
    } else {
      var list = this.parentNode.nextSibling;
      list.style.display = list.style.display === 'none' ? 'block' : 'none';
    }

    // don't follow the clicked link
    YAHOO.util.Event.preventDefault(e);
  }
}

// When the window has finished loading, call the init method
YAHOO.util.Event.addListener(window,'load',YAHOO.example.proxyajax.init);