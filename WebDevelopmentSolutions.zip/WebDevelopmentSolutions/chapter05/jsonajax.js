YAHOO.example.jsonajax={

  // the initialization function 
  init:function(){

    // get all links with the class "delcious"	
    var links = YAHOO.util.Dom.getElementsByClassName('delicious','a');

	// fire the "get" method when the user clicks them 
    YAHOO.util.Event.addListener(links,'click',YAHOO.example.jsonajax.get);
  },

  // the get method that retrieves the information
  get:function(e){
    if(this.hasloaded===undefined){
      var url = this.getAttribute('href');
      YAHOO.example.jsonajax.origin = this;
      YAHOO.example.jsonajax.text = this.innerHTML;
      this.innerHTML = 'Loading...';

      // In order to turn a normal del.icio.us URL into a JSON feed, just add feeds/json/
      var feedurl = url.replace(/\.us/,'.us/feeds/json/');
      feedurl += '?callback=YAHOO.example.jsonajax.datafound';
      var s = document.createElement('script');
	  s.src = feedurl;
	  document.body.appendChild(s);

	// if there is already a list of links, just toggle their display   
    } else {
      var list = this.parentNode.nextSibling;
      list.style.display = list.style.display === 'none' ? 'block' : 'none';
    }

    // don't follow the clicked link
    YAHOO.util.Event.preventDefault(e);
  },
  datafound:function(o){
    var out='';
      for (var item in o) {
	    out+='<li><a href="'+o[item].u+'">'+o[item].d+'</a></li>';
      }
	YAHOO.example.jsonajax.origin.innerHTML = YAHOO.example.jsonajax.text;
	var list = document.createElement('ul');
	list.className = 'linkslist';
	YAHOO.example.jsonajax.origin.hasloaded = true;
	var parent = YAHOO.example.jsonajax.origin.parentNode;
	parent.parentNode.insertBefore(list, parent.nextSibling);
	list.innerHTML = out;
  }
}

// When the window has finished loading, call the init method
YAHOO.util.Event.addListener(window,'load',YAHOO.example.jsonajax.init);