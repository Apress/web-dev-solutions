// This function will be called every time the user clicks on the 
// navigation list

YAHOO.example.lyricsajax = function(e){

  // Get the element that was clicked on by using the getTarget()
  // method of the event utility
  
  var t = YAHOO.util.Event.getTarget(e);

  // ensure that the element is a link by comparing its node name

  if(t.nodeName.toLowerCase() === 'a'){

	// This function is called when the file was successfully loaded
    function success(obj) { 
	  // reset the link text back to the original text 
      t.innerHTML = currentText;
      // get the text content of the file that was loaded
      var d = obj.responseText;
      // remove all the whitespace to turn it into one line
      d = d.replace(/\n|\r/g,'');
      // remove everything before and including the starting tag of the content DIV
      d = d.replace(/.*<div id="lyricscontainer">/,'');
      // remove the rest of the document after the lyrics
      d = d.replace(/<\/div>.*/,'');
      // insert the lyrics content into the document
      document.getElementById('lyricscontainer').innerHTML = d;
    }

	// This function is called when there was an error
    function failure(obj) {
	  // reset the link text back to the original text 
      t.innerHTML = currentText;

      // if the connection timed out, tell the visitor that
      if(obj.status === -1){
        var error = '<h2>There was an error</h2>';
        error += '<p>The connection timed out. You can try to ';
        error += '<a href="' + t.href + '">load the document again</a>.</p>';

      // if the document couldn't be found, tell the visitor that 
      }else if(obj.status === 404){ 
        var error = '<h2>There was an error</h2>';
        error+= '<p>The document was not found.</p>';
        document.getElementById('lyricscontainer').innerHTML = error;

      // report other errors, too
      } else {
        var error = '<h2>There was an error</h2><p>' + obj.statusText +' </p>';
      }

      // display the error message inside the lyrics container
      document.getElementById('lyricscontainer').innerHTML = error;
    }

	// Define the handlers for the connection. 
	//    - success defines the function that is called when the document 
	//      was loaded 
	//    - failure defines the function that is called when there was a 
	//      problem
	//    - timeout defines the amount of time in milliseconds to wait before
	//      the connection is considered timed out.
    var handlers={
      success: success,
      failure: failure,
      timeout: 2000
    }

    // get the url to load from the link's HREF attribute
    var url = t.href;

    // define a new asynchronous request loading the url using the parameters
	// defined in handlers
    var cObj = YAHOO.util.Connect.asyncRequest('GET', url, handlers);

    // store the link text in a variable called currentText
    var currentText = t.innerHTML;

    // turn the link text into a loading message
    t.innerHTML = 'loading...';

    // don't follow the link when the visitor clicks it by using the 
	// preventDefault method of the event utility
    YAHOO.util.Event.preventDefault(e);
  }  
}

// When the element with the ID lyricsnav is available, attach an event listener
// that calls the function YAHOO.example.lyricsajax when the user clicks the 
// element
YAHOO.util.Event.addListener('lyricsnav', 'click', YAHOO.example.lyricsajax);
