<?php

// set the correct header to return a real XML document
header("Content-Type:text/xml");

// retrieve the URL that was sent by the paramater with the same name
$url = $_GET['url'];

// get the document and print it out
$feed = getResource($url);
echo $feed;

// this function CURL to read $url from a different server and return it
function getResource($url){
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  $result = curl_exec($ch);
  curl_close($ch);
  return $result;
}

?>
