// when the document has finished loading
$( document ) . ready ( 
  function() {
    // add a class called "dynamic" to the element with the ID nav
    $( '#nav' ).addClass('dynamic');
	// loop through all UL elements inside the "nav" element
    $( '#nav ul' ).each(
      function(){
        // add a class called "parent" to the parent element of the current UL
        $(this.parentNode).addClass('parent');
      }
    );
	// if the visitor clicks on any link inside the "nav" element
    $('#nav a').click( 
      function(){
        // get all lists inside the parent node of this link
        var uls = this.parentNode.getElementsByTagName('ul');
		// if there is at least one
        if(uls.length>0){
          // check its style display attribute and toggle it from block to none
          uls[0].style.display=uls[0].style.display=='block'?'none':'block';
          // don't follow the link
		  return false;
        }
      }
    );
  }
);
