YAHOO.example.animateMenu = {
  // predefine a property to store the visibility status of the menu
  menuvisible:false,
  // initialization method
  init:function(){
    // store the height of the menu in menuheight
    YAHOO.example.animateMenu.menuheight = this.offsetHeight;
    // add a CSS class called dynamic to the menu, thus hiding it
    YAHOO.util.Dom.addClass(this, 'dynamic');
    // create a new link element and give it a href to make it display as a link
    YAHOO.example.animateMenu.trigger = document.createElement('a');
    YAHOO.example.animateMenu.trigger.setAttribute('href', '#');
    // add the text "show menu" to the link
    YAHOO.example.animateMenu.trigger.appendChild(document.createTextNode('show menu'));
    // insert the link before the menu
    this.parentNode.insertBefore(YAHOO.example.animateMenu.trigger,this);
    // call the method togglemenu when a user clicks the link
    YAHOO.util.Event.addListener(YAHOO.example.animateMenu.trigger, 'click', YAHOO.example.animateMenu.togglemenu );
  },
  // method to show and hide the menu
  togglemenu:function(e){
    // if the menu is hidden
    if(YAHOO.example.animateMenu.menuvisible === false){
    // set the menu height to zero (to avoid it flashing up before the
    // animation starts)
      YAHOO.util.Dom.setStyle('nav', 'height', '0');
      // remove the CSS class to show the menu
      YAHOO.util.Dom.removeClass('nav', 'dynamic');
      // define the end value of the animation as the original height 
      // of the menu
      var end = YAHOO.example.animateMenu.menuheight;
      // animation attributes - animate until the height is the original 
      // height
      var attributes = {height:{to:end}};
      // set the property to state that the menu is visible
      YAHOO.example.animateMenu.menuvisible = true;
      // change the text of the link to "hide menu"
      var linktext = 'hide menu';
    // if the menu is visible...
    } else {
      // define the end value of the animation as 0
      var attributes = {height:{to:0}};
      // set the property to state that the menu is hidden
      YAHOO.example.animateMenu.menuvisible = false;
      // change the text of the link to "show menu"
      var linktext = 'show menu';
    }
    // define a new animation to change the element with the ID nav 
    // using the defined attributes, a duration of one second 
    // and start and end slower using the Easing methods. 
    var anim = new YAHOO.util.Anim('nav', attributes, 1, YAHOO.util.Easing.easeBoth);
    // start the animation
    anim.animate();
    // when the animation is finished
    anim.onComplete.subscribe(
      function(){
        // change the text of the link 
        YAHOO.example.animateMenu.trigger.firstChild.nodeValue = linktext;
      }
    );   
    // don't follow the original link
    YAHOO.util.Event.preventDefault(e);
  }
}
// execute the initialization method as soon as the element 
// with the ID "nav" is available.
YAHOO.util.Event.onAvailable('nav', YAHOO.example.animateMenu.init);