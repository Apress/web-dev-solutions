// when the DOM of the page is ready
Window.onDomReady(
  function(){
    // add the CSS class "dynamic" to the element with the ID "nav"
    $('nav').addClass('dynamic');
    // get all LI elements inside the element with the ID "nav"
    $lis = $('nav').getElements('li');
    // loop through all the list items
    $lis.each(
	  // the each() method parses each list item as the parameter o
      function(o){
        // if the list item contains UL elements
        if($(o).getElements('ul').length>0){
          // add a CSS class to the list item with the name "parent"
          o.addClass('parent');
		  // get the first link inside the list item     
          var trigger = $E('a', o);
          // execute a function when the visitor clicks the link		  
          trigger.addEvent('click', 
            function(e){
              // get the first nested UL element and toggle its display 
              var nest = o.getElements('ul')[0];
              nest.style.display=nest.style.display=='block'?'none':'block';
			  // don't follow the link
              return Window.stopEvent(e);
            }
          )
        }
      }
    );
  }
);
// Hack extension to allow links not being followed when the user clicks them
Window.extend({ 
  stopEvent: function(e){
    if (e.stopPropagation){ 
      e.stopPropagation(); 
      e.preventDefault(); 
    } else { 
      e.returnValue = false; 
      e.cancelBubble = true; 
    } return false; } 
});
