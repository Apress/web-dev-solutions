// when the DOM of the page is ready
Window.onDomReady(
  function(){
    // add the CSS class "dynamic" to the element with the ID "nav"
    // thus hiding it
    $('nav').addClass('dynamic');
    // create a new link element, set the href attribute to # (to make it appear
    // as a link) and add a text inside the link saying "show menu"
    var trigger = new Element('a');
    trigger.setProperty('href','#');
    trigger.appendText('show menu');
    // add the new link before the menu to the document 
    $(trigger).injectBefore('nav');
    // define a new slide effect for the menu
    var slideeffect = new Fx.Slide('nav');
    // hide the menu initially
    slideeffect.hide();
    // make the newly added link execute a function when a visitor clicks it
    $(trigger).addEvent(
    'click',
       // function to toggle the menu state
       function(e){
         // alternately show and hide the menu and slide it open or closed
         slideeffect.toggle('vertical');
         // change the text of the trigger link accordingly
         if($(trigger).innerHTML === 'show menu'){
           $(trigger).innerHTML = 'hide menu';
         } else {
           $(trigger).innerHTML = 'show menu'; 
         } 
         // don't follow the link
         return Window.stopEvent(e);
       }
    )  
  }
);
// Hack extension to allow links not being followed when the user clicks them
Window.extend({ 
  stopEvent: function(e){
    if (e.stopPropagation){ 
      e.stopPropagation(); 
      e.preventDefault(); 
    } else { 
      e.returnValue = false; 
      e.cancelBubble = true; 
    } return false; } 
});
