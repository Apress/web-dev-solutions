// when the document has finished loading
$( document ) . ready ( 
  function() {
	// hide the navigation element
	$('#nav').hide();
	// create a link to show and hide the navigation
	$('#nav').before('<a href="#">show menu</a>');
	// define alternatives to execute alternately when the visitor clicks the 
	// link
	$('#nav').prev().toggle(
		// set the text of the link to "hide menu" and show the menu
		function(){
			$(this).html('hide menu');
			$('#nav').slideToggle('medium');
		},
		// set the text of the link to "show menu" and hide the menu
		function(){
			$(this).html('show menu');
			$('#nav').slideToggle('medium');
		}
	);
  }
);
