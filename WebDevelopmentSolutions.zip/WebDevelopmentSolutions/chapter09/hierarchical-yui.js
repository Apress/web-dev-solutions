
// use the example namespace and call the main object "tree"
YAHOO.example.tree = {

  // the init function to hide elements and add the "parent" classes
  init:function(){

    // add a class called dynamic to the element that was sent as a 
    // parameter (stored in this)
    YAHOO.util.Dom.addClass(this,'dynamic');
    
    // add an event listener that calls the toggle method when a visitor
    // clicks anywhere inside the tree element
    YAHOO.util.Event.addListener(this, 'click', YAHOO.example.tree.toggle);

    // grab all UL elements inside the element and loop through each of them
    var uls = this.getElementsByTagName('ul');
    for(var i=uls.length-1;i>-1;i--){

      // add a class called "parent" to each LI that contains a UL
      YAHOO.util.Dom.addClass(uls[i].parentNode, 'parent');

    }
  },

  // the method to show and hide the nested lists
  toggle:function(e){

    // use the Event component to find out which element was clicked on 
    var t = YAHOO.util.Event.getTarget(e);

    // compare if the element had the name "a", thus being a link
    if(t.nodeName.toLowerCase()==='a'){

      // check if the link is inside an LI that has a nested UL element
      var nestedLists = t.parentNode.getElementsByTagName('ul');
      if( nestedLists.length > 0 ){

        // toggle the display of the nested UL
        nestedLists[0].style.display = nestedLists[0].style.display === 'block'?'none':'block';

        // don't follow the link
        YAHOO.util.Event.preventDefault(e);
      }    
    }
  }
}

// as soon as the element with the ID 'nav' is available, call the init method
YAHOO.util.Event.onAvailable('nav', YAHOO.example.tree.init);
