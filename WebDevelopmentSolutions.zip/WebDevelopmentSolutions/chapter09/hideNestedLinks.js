  function hideStuff(){
    var lists = document.getElementsByTagName( 'ul' );
    for(var i = 0, j = lists.length; i < j; i++){
    if(lists[i].parentNode.nodeName.toLowerCase() === 'li'){
        lists[i].style.display = 'none';
      }
    }
  }
  hideStuff();
